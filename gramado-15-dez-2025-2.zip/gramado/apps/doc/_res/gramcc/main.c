

// gramcc.c será um wrapper que chamará qualquer compilador da coleção. 







int gramcc_main ( int c, char *argv[] ){
	
	//#todo.
    //Devemos copiar os primeiros arquivos que estão em /gamcc/c
    //Esse programa apenas pegará os argumentos e chamará 
    //o compilador certo. Não fá nenhuma análise de código.	
	
	return 0;
};
