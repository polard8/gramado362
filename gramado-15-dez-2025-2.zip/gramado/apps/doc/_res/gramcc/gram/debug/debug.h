
//verbose

#define GRAMC_VERBOSE 1

//isso é usado no debug .

//vamos configurar o modo como o compilador deve rodar,
//quais verboses ele deve mostrar.


//#define LEXER_VERBOSE 1   //verbose genérido do lexer
//#define LEXER_
//#define LEXER_
//#define LEXER_

//#define PARSER_VERBOSE 1   //verbose genérido do parser
//#define PARSER_OUTPUT_VERBOSE 1
//#define PARSER_EXPRESSION_VERBOSE 1
//#define PARSER_IF_VERBOSE 1
//#define PARSER_WHILE_VERBOSE 1
//#define PARSER_SIZEOF_VERBOSE 1
//#define PARSER_RETURN_VERBOSE 1
//#define PARSER_FUNCTION_VERBOSE 1
//#define PARSER_ASM_VERBOSE 1
