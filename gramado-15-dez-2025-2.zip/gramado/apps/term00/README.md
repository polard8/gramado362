# terminal

```
 * This is the virtual terminal, terminal.bin. It is a client-side GUI application.
 * It has an embedded command line interface receaving system message.
 * At the second stage it is able to receive input from stderr, sent by the shell. Type 'start-shell'.
 * The plan is to use the tty infrastructure.
```
