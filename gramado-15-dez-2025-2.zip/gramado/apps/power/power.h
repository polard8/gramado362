// power.h

#ifndef __POWER_H
#define __POWER_H    1

extern struct gws_display_d *Display;

#endif  

