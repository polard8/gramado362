# gramci

	gramci - Gramado Consistent Interface


	==========================================
	cmd:
	Standard unix-like commands.
	It will run on virtual consoles and virtual terminals.
	It uses the rtl.
	
	==========================================
	core:
	Some core components. Just like window server.
	
	==========================================
	edge:
	Edge compnents, just like browser and network UI.

	==========================================
	setup:
	Setup environment. Used to install and upgrade the system.

	==========================================
	shell:
	Operating system shell, just like launchers, window managers.

