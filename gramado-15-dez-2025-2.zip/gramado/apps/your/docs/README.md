# de/docs

This folder has the documentation for the Desktop Environment. 
The main goal here is explain how the user can use the operating system.

```
 * dn/ -  Design notes.
```




