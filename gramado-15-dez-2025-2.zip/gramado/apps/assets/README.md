# assets - Resources for the GUI
 