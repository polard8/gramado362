// menuapp.h

#ifndef __MENUAPP_H
#define __MENUAPP_H    1

extern struct gws_display_d *Display;

#endif  

