//https://linux.die.net/man/3/update_panels


// panel - panel stack extension for curses 