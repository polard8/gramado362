
//libgen.h

/*
//#todo
// these two function are implemented in stdlib.c
char *basename(char *s);
char *dirname(char *s);
*/



