
   /sys

   Os arquivos dessa pasta costuma aparecer em programas unix-like.
   Essa pasta existir� para compatibilidade com esses programas.