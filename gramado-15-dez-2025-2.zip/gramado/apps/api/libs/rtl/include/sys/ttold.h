
//arquivo criado para compatibilidade com bash 105


