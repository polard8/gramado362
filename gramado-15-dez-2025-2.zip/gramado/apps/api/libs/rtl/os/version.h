/* Version strings */

#define __VERSION         "0"
#define __PATCHLEVEL      "0"
#define __SUBLEVEL        "0"
#define __EXTRAVERSION    "-rc0"
#define __NAME            "Gramado LibC"


