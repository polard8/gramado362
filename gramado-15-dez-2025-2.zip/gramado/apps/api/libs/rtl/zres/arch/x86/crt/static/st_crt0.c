

extern int _st_main ( int argc, char * argv[] );
	
void st_crt0 (){

	//#todo
	_st_main ( 0, NULL );
	

    while (1){}
}

