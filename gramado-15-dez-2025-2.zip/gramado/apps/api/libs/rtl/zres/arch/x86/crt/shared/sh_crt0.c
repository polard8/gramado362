



extern int _sh_main ( int argc, char * argv[] );
	
void sh_crt0 (){

	//#todo
	_sh_main ( 0, NULL );
	

    while (1){}
}



