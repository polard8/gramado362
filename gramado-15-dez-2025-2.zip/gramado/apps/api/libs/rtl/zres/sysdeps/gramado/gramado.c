
// #obs
// a syscall está em stubs/
// Aqui vamos criar outras interações com 
// elementes específicos do sistema Gramado.


#include "gramado.h"

