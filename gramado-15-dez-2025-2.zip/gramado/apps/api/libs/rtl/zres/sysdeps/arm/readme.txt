Initializing folder.
