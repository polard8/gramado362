


    /gdeio
	
	
	Biblioteca para que os drivers e servidores em user mode possam acessar
	as portas.
	
	
	gde_inport8 (unsigned short port)
	gde_inport16 (unsigned short port)
	gde_inport32 (unsigned short port)
	
	gde_outport8 ( unsigned short port, unsigned char value)
	gde_outport16 ( unsigned short port, unsigned short value)
	gde_outport32 ( unsigned short port, unsigned long value)